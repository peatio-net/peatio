module Irix
  VERSION = "3.1.1"
end
